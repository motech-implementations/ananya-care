package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.measure.MoveBeneficiaryForm;
import org.motechproject.mds.service.MotechDataService;


public interface MoveBeneficiaryFormMDSService extends
MotechDataService<MoveBeneficiaryForm> {

}