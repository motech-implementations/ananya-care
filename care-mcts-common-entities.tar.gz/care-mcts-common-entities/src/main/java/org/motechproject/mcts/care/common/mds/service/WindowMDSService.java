package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.domain.Window;
import org.motechproject.mds.service.MotechDataService;

public interface WindowMDSService extends MotechDataService<Window> {

}
