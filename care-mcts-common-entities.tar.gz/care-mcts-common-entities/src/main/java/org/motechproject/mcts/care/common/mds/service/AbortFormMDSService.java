package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.measure.AbortForm;
import org.motechproject.mds.service.MotechDataService;


public interface AbortFormMDSService extends
MotechDataService<AbortForm> {

}