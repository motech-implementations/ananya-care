package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.measure.AwwGrowthMonitoringChildForm2;
import org.motechproject.mds.service.MotechDataService;

public interface AwwGrowthMonitoringChildForm2MDSService extends
MotechDataService<AwwGrowthMonitoringChildForm2> {

}