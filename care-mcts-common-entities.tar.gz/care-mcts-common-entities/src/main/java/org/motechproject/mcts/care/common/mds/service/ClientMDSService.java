package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.domain.Client;
import org.motechproject.mds.service.MotechDataService;

public interface ClientMDSService extends MotechDataService<Client> {

}
