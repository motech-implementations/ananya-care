package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.measure.DeathMotherForm;
import org.motechproject.mds.service.MotechDataService;


public interface DeathMotherFormMDSService extends
MotechDataService<DeathMotherForm> {

}