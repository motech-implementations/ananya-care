package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.model.MctsPregnantMotherServiceUpdate;
import org.motechproject.mds.service.MotechDataService;

public interface MctsPregnantMotherServiceUpdateMDSService extends MotechDataService<MctsPregnantMotherServiceUpdate> {

}
