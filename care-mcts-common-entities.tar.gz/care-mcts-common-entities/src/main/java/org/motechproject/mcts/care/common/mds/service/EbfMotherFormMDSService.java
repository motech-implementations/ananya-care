package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.measure.EbfMotherForm;
import org.motechproject.mds.service.MotechDataService;


public interface EbfMotherFormMDSService extends
MotechDataService<EbfMotherForm> {

}