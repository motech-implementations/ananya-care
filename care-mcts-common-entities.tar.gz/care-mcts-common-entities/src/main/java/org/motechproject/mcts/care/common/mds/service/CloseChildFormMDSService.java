package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.measure.CloseChildForm;
import org.motechproject.mds.service.MotechDataService;


public interface CloseChildFormMDSService extends
MotechDataService<CloseChildForm> {

}