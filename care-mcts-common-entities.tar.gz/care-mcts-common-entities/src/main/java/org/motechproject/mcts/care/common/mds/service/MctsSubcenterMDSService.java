package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.model.MctsSubcenter;
import org.motechproject.mds.service.MotechDataService;

public interface MctsSubcenterMDSService extends MotechDataService<MctsSubcenter> {

}
