package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.measure.CfMotherForm;
import org.motechproject.mds.service.MotechDataService;

public interface CfMotherFormMDSService extends
MotechDataService<CfMotherForm> {

}