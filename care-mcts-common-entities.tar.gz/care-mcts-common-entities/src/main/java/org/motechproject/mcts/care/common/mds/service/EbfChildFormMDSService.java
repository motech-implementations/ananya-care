package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.measure.EbfChildForm;
import org.motechproject.mds.service.MotechDataService;

public interface EbfChildFormMDSService extends
MotechDataService<EbfChildForm> {

}