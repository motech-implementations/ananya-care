package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.dimension.Flw;
import org.motechproject.mds.service.MotechDataService;

public interface FlwMDSService extends MotechDataService<Flw> {
    

}
