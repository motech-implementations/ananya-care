package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.dimension.MotherCase;
import org.motechproject.mds.service.MotechDataService;

public interface MotherCaseMDSService extends MotechDataService<MotherCase> {

}
