package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.measure.AwwEditChildForm;
import org.motechproject.mds.service.MotechDataService;

public interface AwwEditChildFormMDSService extends
MotechDataService<AwwEditChildForm> {

}