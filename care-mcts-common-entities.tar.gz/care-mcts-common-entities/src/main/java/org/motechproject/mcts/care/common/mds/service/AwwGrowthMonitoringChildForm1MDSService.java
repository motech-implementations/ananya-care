package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.measure.AwwGrowthMonitoringChildForm1;
import org.motechproject.mds.service.MotechDataService;


public interface AwwGrowthMonitoringChildForm1MDSService extends
MotechDataService<AwwGrowthMonitoringChildForm1> {

}