package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.measure.NewForm;
import org.motechproject.mds.service.MotechDataService;

public interface NewFormMDSService extends
MotechDataService<NewForm> {

}