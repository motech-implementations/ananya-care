package org.motechproject.mcts.care.common.lookup;

public interface CaseType { 
    public static final String TASK = "task";
    public static final String MOTHER = "cc_bihar_pregnancy";
    public static final String CHILD = "cc_bihar_newborn";
    /*Mother("cc_bihar_pregnancy"),
    Child("cc_bihar_newborn"),
    Task("task");
    
    private String caseType;

    CaseType(String case_type) {
        this.caseType=case_type;
    }

    public String getType() {
        return caseType;
    }
*/
}