package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.measure.PncMotherForm;
import org.motechproject.mds.service.MotechDataService;

public interface PncMotherFormMDSService extends
MotechDataService<PncMotherForm> {

}