package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.model.MctsTaluk;
import org.motechproject.mds.service.MotechDataService;

public interface MctsTalukMDSService extends MotechDataService<MctsTaluk> {

}
