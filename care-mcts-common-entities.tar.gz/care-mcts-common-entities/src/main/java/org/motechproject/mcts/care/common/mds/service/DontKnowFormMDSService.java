package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.measure.DontKnowForm;
import org.motechproject.mds.service.MotechDataService;

public interface DontKnowFormMDSService extends MotechDataService<DontKnowForm> {

}
