package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.measure.DeathChildForm;
import org.motechproject.mds.service.MotechDataService;


public interface DeathChildFormMDSService extends
MotechDataService<DeathChildForm> {

}