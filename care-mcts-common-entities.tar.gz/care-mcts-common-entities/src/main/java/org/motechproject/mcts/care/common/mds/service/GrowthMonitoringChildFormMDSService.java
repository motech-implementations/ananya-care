package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.measure.GrowthMonitoringChildForm;
import org.motechproject.mds.service.MotechDataService;

public interface GrowthMonitoringChildFormMDSService extends
MotechDataService<GrowthMonitoringChildForm> {

}