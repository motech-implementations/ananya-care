package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.measure.ReferChildForm;
import org.motechproject.mds.service.MotechDataService;


public interface ReferChildFormMDSService extends
MotechDataService<ReferChildForm> {

}