package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.measure.MiForm;
import org.motechproject.mds.service.MotechDataService;


public interface MiFormMDSService extends
MotechDataService<MiForm> {

}