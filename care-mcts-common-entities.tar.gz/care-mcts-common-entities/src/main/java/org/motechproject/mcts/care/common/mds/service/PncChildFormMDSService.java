package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.measure.PncChildForm;
import org.motechproject.mds.service.MotechDataService;


public interface PncChildFormMDSService extends
MotechDataService<PncChildForm> {

}