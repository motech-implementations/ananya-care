package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.measure.BpForm;
import org.motechproject.mds.service.MotechDataService;


public interface BpFormMDSService extends
MotechDataService<BpForm> {

}