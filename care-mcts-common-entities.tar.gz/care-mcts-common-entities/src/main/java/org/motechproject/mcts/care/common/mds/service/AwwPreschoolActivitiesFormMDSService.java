package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.measure.AwwPreschoolActivitiesForm;
import org.motechproject.mds.service.MotechDataService;


public interface AwwPreschoolActivitiesFormMDSService extends
MotechDataService<AwwPreschoolActivitiesForm> {

}