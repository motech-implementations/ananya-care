package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.dimension.ChildCase;
import org.motechproject.mds.service.MotechDataService;

public interface ChildCaseMDSService extends
MotechDataService<ChildCase> {

}
