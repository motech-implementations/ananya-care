package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.model.MctsState;
import org.motechproject.mds.service.MotechDataService;

public interface MctsStateMDSService extends MotechDataService<MctsState> {

}
