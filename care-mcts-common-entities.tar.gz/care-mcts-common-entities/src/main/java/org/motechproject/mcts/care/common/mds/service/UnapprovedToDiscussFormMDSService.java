package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.measure.UnapprovedToDiscussForm;
import org.motechproject.mds.service.MotechDataService;

public interface UnapprovedToDiscussFormMDSService extends MotechDataService<UnapprovedToDiscussForm> {

}
