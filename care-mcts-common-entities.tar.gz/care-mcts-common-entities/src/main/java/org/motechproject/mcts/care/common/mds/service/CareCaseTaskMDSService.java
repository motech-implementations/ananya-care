package org.motechproject.mcts.care.common.mds.service;

import org.motechproject.mcts.care.common.mds.domain.CareCaseTask;
import org.motechproject.mds.service.MotechDataService;

public interface CareCaseTaskMDSService extends MotechDataService<CareCaseTask> {

}
