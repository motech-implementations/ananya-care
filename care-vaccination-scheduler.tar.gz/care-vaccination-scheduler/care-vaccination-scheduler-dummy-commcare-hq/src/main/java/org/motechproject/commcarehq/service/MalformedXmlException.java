package org.motechproject.commcarehq.service;

public class MalformedXmlException extends RuntimeException {
}
