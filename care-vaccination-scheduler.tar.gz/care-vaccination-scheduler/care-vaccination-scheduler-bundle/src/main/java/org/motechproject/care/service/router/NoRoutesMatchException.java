package org.motechproject.care.service.router;

public class NoRoutesMatchException extends RuntimeException {
}
