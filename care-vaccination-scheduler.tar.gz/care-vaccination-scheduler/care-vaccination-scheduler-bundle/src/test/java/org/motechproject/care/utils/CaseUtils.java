package org.motechproject.care.utils;

public class CaseUtils {

    public static String getUniqueCaseId(){
        return "caseId"+Math.random();

    }
}
